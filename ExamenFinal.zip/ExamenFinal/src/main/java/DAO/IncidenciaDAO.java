/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
import modelo.Incidencia;
import util.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Usuario
 */
public class IncidenciaDAO {
    public void registrar(Incidencia inc) {
        String sql = "INSERT INTO incidencias (id_empleado, descripcion, prioridad, estado, fecha_creacion) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inc.getIdEmpleado());
            stmt.setString(2, inc.getDescripcion());
            stmt.setString(3, inc.getPrioridad());
            stmt.setString(4, inc.getEstado());
            stmt.setDate(5, inc.getFechaCreacion());
            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("Error al registrar incidencia: " + e.getMessage());
        }
    }

    public List<Incidencia> listarTodas() {
        List<Incidencia> lista = new ArrayList<>();
        String sql = "SELECT * FROM incidencias";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                lista.add(new Incidencia(
                    rs.getInt("id"),
                    rs.getInt("id_empleado"),
                    rs.getString("descripcion"),
                    rs.getString("prioridad"),
                    rs.getString("estado"),
                    rs.getDate("fecha_creacion"),
                    rs.getDate("fecha_resolucion")
                ));
            }

        } catch (Exception e) {
            System.out.println("Error al listar incidencias: " + e.getMessage());
        }

        return lista;
    }

    public void cambiarEstado(int idIncidencia, String nuevoEstado, Date fechaResolucion) {
        String sql = "UPDATE incidencias SET estado = ?, fecha_resolucion = ? WHERE id = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nuevoEstado);
            stmt.setDate(2, fechaResolucion);
            stmt.setInt(3, idIncidencia);
            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("Error al cambiar estado: " + e.getMessage());
        }
    }

    public void eliminar(int id) {
        String sql = "DELETE FROM incidencias WHERE id = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (Exception e) {
            System.out.println("Error al eliminar incidencia: " + e.getMessage());
        }
    }

    public boolean existeIncidenciaCerradaConDescripcion(int idEmpleado, String descripcion) {
        String sql = "SELECT COUNT(*) FROM incidencias WHERE id_empleado = ? AND descripcion = ? AND estado = 'Cerrada'";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idEmpleado);
            stmt.setString(2, descripcion);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (Exception e) {
            System.out.println("Error al verificar duplicado: " + e.getMessage());
        }
        return false;
    }
    public List<Incidencia> listar() {
    List<Incidencia> lista = new ArrayList<>();
    String sql = """
        SELECT i.id, i.id_empleado, i.descripcion, i.prioridad,
               i.estado, i.fecha_creacion, i.fecha_resolucion,
               e.nombre AS nombre_empleado
        FROM incidencias i
        JOIN empleados e ON i.id_empleado = e.id
        ORDER BY i.id DESC
        """;

    try (Connection conn = ConexionDB.getConexion();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            Incidencia i = new Incidencia(
                rs.getInt("id"),
                rs.getInt("id_empleado"),
                rs.getString("descripcion"),
                rs.getString("prioridad"),
                rs.getString("estado"),
                rs.getDate("fecha_creacion"),
                rs.getDate("fecha_resolucion")
            );
            i.setNombreEmpleado(rs.getString("nombre_empleado")); // Necesitas este campo extra opcional
            lista.add(i);
        }

    } catch (SQLException e) {
        System.out.println("❌ Error al listar incidencias: " + e.getMessage());
    }
    return lista;
}

    private static class ConexionDB {

        private static Connection getConexion() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public ConexionDB() {
        }
    }

}
