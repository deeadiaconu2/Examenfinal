/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import Controlador.EmpleadoControlador;
import Controlador.IncidenciaControlador;
import Controlador.InformeControlador;
import Controlador.TecnicoControlador;
import Controlador.*;
import modelo.*;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author Usuario
 */

public class MenuVista {
    private final Scanner scanner = new Scanner(System.in);
    private final TecnicoControlador tecnicoCtrl = new TecnicoControlador();
    private final EmpleadoControlador empleadoCtrl = new EmpleadoControlador();
    private final IncidenciaControlador incidenciaCtrl = new IncidenciaControlador();
    private final InformeControlador informeCtrl = new InformeControlador();
    private Tecnico tecnicoActual = null;

    public void iniciar() {
        while (true) {
            System.out.println("=== Sistema de Gestión de Incidencias ===");
            System.out.print("Usuario: ");
            String usuario = scanner.nextLine();
            System.out.print("Contraseña: ");
            String password = scanner.nextLine();

            tecnicoActual = tecnicoCtrl.login(usuario, password);
            if (tecnicoActual != null) {
                menuPrincipal();
            }
        }
    }

    private void menuPrincipal() {
        int opcion;
        do {
            System.out.println("\n=== Menú Principal ===");
            System.out.println("1. Gestionar Empleados");
            System.out.println("2. Gestionar Incidencias");
            System.out.println("3. Ver Incidencias por Estado");
            System.out.println("4. Ver Historial de un Empleado");
            System.out.println("5. Ver Informes Generales");
            System.out.println("6. Cerrar Sesión");
            opcion = leerEntero("Seleccione una opción: ");

            switch (opcion) {
                case 1 -> menuEmpleados();
                case 2 -> menuIncidencias();
                case 3 -> filtrarPorEstado();
                case 4 -> verHistorialEmpleado();
                case 5 -> informeCtrl.mostrarInformeGeneral();
                case 6 -> System.out.println("Cerrando sesión...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 6);
    }

    private void menuEmpleados() {
        System.out.println("--- Gestión de Empleados ---");
        String nombre = leerTexto("Nombre del empleado: ");
        String email = leerTexto("Email del empleado: ");
        empleadoCtrl.crearEmpleado(nombre, email);
    }

    private void menuIncidencias() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Incidencias ---");
            System.out.println("1. Registrar Incidencia");
            System.out.println("2. Listar Todas");
            System.out.println("3. Cambiar Estado");
            System.out.println("4. Eliminar Incidencia");
            System.out.println("5. Volver");
            opcion = leerEntero("Opción: ");

            switch (opcion) {
                case 1 -> registrarIncidencia();
                case 2 -> listarIncidencias();
                case 3 -> cambiarEstadoIncidencia();
                case 4 -> eliminarIncidencia();
                case 5 -> System.out.println("↩ Volviendo...");
                default -> System.out.println("❌ Opción no válida.");
            }
        } while (opcion != 5);
    }

    private void registrarIncidencia() {
        int idEmpleado = leerEntero("ID del empleado: ");
        String descripcion = leerTexto("Descripción: ");
        String prioridad = leerTexto("Prioridad (Alta, Media, Baja): ");
        Incidencia i = new Incidencia(0, idEmpleado, descripcion, prioridad, "Abierta", new java.sql.Date(System.currentTimeMillis()), null);
        incidenciaCtrl.registrar(i);
    }

    private void listarIncidencias() {
        List<Incidencia> lista = method();
        for (Incidencia i : lista) {
            System.out.printf("ID: %d | Empleado: %d | Prioridad: %s | Estado: %s | Fecha: %s\n",
                i.getId(), i.getIdEmpleado(), i.getPrioridad(), i.getEstado(), i.getFechaCreacion());
        }
    }

    private List<Incidencia> method() {
        List<Incidencia> lista = incidenciaCtrl.listar();
        return lista;
    }

    private void cambiarEstadoIncidencia() {
        int id = leerEntero("ID de la incidencia: ");
        String nuevoEstado = leerTexto("Nuevo estado (Abierta, En proceso, Cerrada): ");
        incidenciaCtrl.cambiarEstado(id, nuevoEstado);
    }

    private void eliminarIncidencia() {
        int id = leerEntero("ID de la incidencia a eliminar: ");
        incidenciaCtrl.eliminar(id);
    }

    private void filtrarPorEstado() {
        String estado = leerTexto("Ingrese el estado a buscar (Abierta, En proceso, Cerrada): ");
        List<Incidencia> lista = method(); // Puedes crear una función filtrarPorEstado si gustas
        for (Incidencia i : lista) {
            if (i.getEstado().equalsIgnoreCase(estado)) {
                System.out.printf("ID: %d | Empleado: %d | Estado: %s | Prioridad: %s\n",
                    i.getId(), i.getIdEmpleado(), i.getEstado(), i.getPrioridad());
            }
        }
    }

    private void verHistorialEmpleado() {
        int idEmpleado = leerEntero("ID del empleado: ");
        List<Incidencia> lista = method(); // Puedes crear una función listarPorEmpleado
        for (Incidencia i : lista) {
            if (i.getIdEmpleado() == idEmpleado) {
                System.out.printf("ID: %d | Estado: %s | Prioridad: %s | Fecha: %s\n",
                    i.getId(), i.getEstado(), i.getPrioridad(), i.getFechaCreacion());
            }
        }
    }

    // 🔧 Utilidades

    private int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje);
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("❌ Debe ingresar un número.");
            }
        }
    }

    private String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextLine();
    }
}
 
