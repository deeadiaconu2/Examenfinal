/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;
import Controlador.EmpleadoControlador;
import Controlador.IncidenciaControlador;
import Controlador.TecnicoControlador;
import Controlador.*;
import modelo.Tecnico;

import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Consola {
    private static Scanner scanner = new Scanner(System.in);
    private static TecnicoControlador tecnicoControlador = new TecnicoControlador();
    private static EmpleadoControlador empleadoControlador = new EmpleadoControlador();
    private static IncidenciaControlador incidenciaControlador = new IncidenciaControlador();

    public void iniciar() {
        Tecnico tecnico = null;

        while (tecnico == null) {
            System.out.println("=== Sistema de Gestión de Incidencias ===");
            System.out.print("Ingrese su usuario: ");
            String usuario = scanner.nextLine();
            System.out.print("Ingrese su contraseña: ");
            String pass = scanner.nextLine();

            tecnico = tecnicoControlador.login(usuario, pass);
            if (tecnico == null) {
                System.out.println("Credenciales incorrectas.\n");
            }
        }

        menuPrincipal();
    }

    private void menuPrincipal() {
        int opcion;

        do {
            System.out.println("\n=== Menú Principal ===");
            System.out.println("1. Gestionar Empleados");
            System.out.println("2. Gestionar Incidencias");
            System.out.println("3. Ver Incidencias por Estado");
            System.out.println("4. Ver Historial de un Empleado");
            System.out.println("5. Ver Informes Generales");
            System.out.println("6. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1 -> gestionarEmpleados();
                case 2 -> gestionarIncidencias();
                case 3 -> informeControlador.verPorEstado();
                case 4 -> informeControlador.verHistorialPorEmpleado();
                case 5 -> menuInformes();
                case 6 -> System.out.println("Sesión cerrada.");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 6);
    }

    private void gestionarEmpleados() {
        int opcion;

        do {
            System.out.println("\n--- Gestión de Empleados ---");
            System.out.println("1. Registrar Empleado");
            System.out.println("2. Listar Todos");
            System.out.println("3. Eliminar Empleado");
            System.out.println("4. Volver");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1 -> {
                    System.out.print("Nombre: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    empleadoControlador.agregarEmpleado(nombre, email);
                }
                case 2 -> empleadoControlador.mostrarTodos();
                case 3 -> {
                    System.out.print("ID del empleado a eliminar: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    empleadoControlador.eliminar(id);
                }
                case 4 -> {}
                default -> System.out.println("⚠️ Opción inválida.");
            }
        } while (opcion != 4);
    }

    private void gestionarIncidencias() {
        int opcion;

        do {
            System.out.println("\n--- Gestión de Incidencias ---");
            System.out.println("1. Registrar Incidencia");
            System.out.println("2. Listar Todas");
            System.out.println("3. Cambiar Estado");
            System.out.println("4. Eliminar Incidencia");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1 -> {
                    System.out.print("ID del empleado: ");
                    int idEmp = Integer.parseInt(scanner.nextLine());
                    System.out.print("Descripción: ");
                    String desc = scanner.nextLine();
                    System.out.print("Prioridad (Alta/Media/Baja): ");
                    String prio = scanner.nextLine();
                    incidenciaControlador.registrarIncidencia(idEmp, desc, prio);
                }
                case 2 -> incidenciaControlador.listar();
                case 3 -> {
                    System.out.print("ID de la incidencia: ");
                    int idInc = Integer.parseInt(scanner.nextLine());
                    System.out.print("Nuevo estado (Abierta/En proceso/Cerrada): ");
                    String estado = scanner.nextLine();
                    incidenciaControlador.cambiarEstado(idInc, estado);
                }
                case 4 -> {
                    System.out.print("ID de la incidencia a eliminar: ");
                    int id = Integer.parseInt(scanner.nextLine());
                    incidenciaControlador.eliminar(id);
                }
                case 5 -> {}
                default -> System.out.println("⚠️ Opción inválida.");
            }
        } while (opcion != 5);
    }

    private void menuInformes() {
        int opcion;
        do {
            System.out.println("\n--- Informes de Incidencias ---");
            System.out.println("1. Total de Incidencias por Empleado");
            System.out.println("2. Incidencias Abiertas por Prioridad");
            System.out.println("3. Tiempo Promedio de Resolución por Empleado");
            System.out.println("4. Volver");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1 -> informeControlador.totalPorEmpleado();
                case 2 -> informeControlador.abiertasPorPrioridad();
                case 3 -> informeControlador.tiempoPromedioResolucion();
                case 4 -> {}
                default -> System.out.println("⚠️ Opción inválida.");
            }

        } while (opcion != 4);
    }

    private static class informeControlador {

        private static void abiertasPorPrioridad() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void tiempoPromedioResolucion() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void totalPorEmpleado() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void verPorEstado() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private static void verHistorialPorEmpleado() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public informeControlador() {
        }
    }
}
