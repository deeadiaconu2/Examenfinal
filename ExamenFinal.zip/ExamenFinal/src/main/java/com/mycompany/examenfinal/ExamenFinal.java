/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.examenfinal;
import Controlador.IncidenciaControlador;
import Controlador.EmpleadoControlador;
import Controlador.TecnicoControlador;

import java.util.Scanner;
/**
 *
 * @author Usuario
 */
public class ExamenFinal {
public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TecnicoControlador tecnicoCtrl = new TecnicoControlador();
        EmpleadoControlador empleadoCtrl = new EmpleadoControlador();
        IncidenciaControlador incidenciaCtrl = new IncidenciaControlador();

        System.out.println("=== Sistema de Gestión de Incidencias ===");

        // Autenticación
        boolean autenticado = false;
        while (!autenticado) {
            System.out.print("Ingrese su usuario: ");
            String usuario = sc.nextLine();
            System.out.print("Ingrese su contraseña: ");
            String password = sc.nextLine();

            autenticado = tecnicoCtrl.autenticar(usuario, password);
            if (!autenticado) {
                System.out.println("Usuario o contraseña incorrectos. Intente nuevamente.");
            }
        }

        System.out.println("¡Bienvenido al sistema!");

        boolean salir = false;
        while (!salir) {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("1. Gestionar Empleados");
            System.out.println("2. Gestionar Incidencias");
            System.out.println("3. Ver Incidencias por Estado");
            System.out.println("4. Ver Historial de un Empleado");
            System.out.println("5. Ver Informes Generales");
            System.out.println("6. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");
            String opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    // Aquí llamas métodos para gestionar empleados
                    System.out.println("Funcionalidad de gestión de empleados aún no implementada.");
                    break;
                case "2":
                    gestionarIncidencias(sc, incidenciaCtrl);
                    break;
                case "3":
                    // Mostrar incidencias filtradas por estado
                    System.out.println("Funcionalidad para ver incidencias por estado aún no implementada.");
                    break;
                case "4":
                    // Ver historial de incidencias de un empleado
                    System.out.println("Funcionalidad para ver historial de empleado aún no implementada.");
                    break;
                case "5":
                    // Mostrar informes generales
                    System.out.println("Funcionalidad de informes aún no implementada.");
                    break;
                case "6":
                    salir = true;
                    System.out.println("Cerrando sesión...");
                    break;
                default:
                    System.out.println("Opción inválida. Intente de nuevo.");
            }
        }

        sc.close();
    }

    private static void gestionarIncidencias(Scanner sc, IncidenciaControlador incidenciaCtrl) {
        boolean volver = false;

        while (!volver) {
            System.out.println("\n--- Gestión de Incidencias ---");
            System.out.println("1. Registrar Incidencia");
            System.out.println("2. Listar Todas");
            System.out.println("3. Cambiar Estado");
            System.out.println("4. Eliminar Incidencia");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opción: ");
            String opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    System.out.print("ID Empleado: ");
                    int idEmpleado = Integer.parseInt(sc.nextLine());
                    System.out.print("Descripción: ");
                    String descripcion = sc.nextLine();
                    System.out.print("Prioridad (Alta, Media, Baja): ");
                    String prioridad = sc.nextLine();
                    incidenciaCtrl.registrarIncidencia(idEmpleado, descripcion, prioridad);
                    break;
                case "2":
                    incidenciaCtrl.mostrarListado();
                    break;
                case "3":
                    System.out.print("ID Incidencia: ");
                    int idIncidencia = Integer.parseInt(sc.nextLine());
                    System.out.print("Nuevo estado (Abierta, En proceso, Cerrada): ");
                    String nuevoEstado = sc.nextLine();
                    incidenciaCtrl.cambiarEstado(idIncidencia, nuevoEstado);
                    break;
                case "4":
                    System.out.print("ID Incidencia a eliminar: ");
                    int idEliminar = Integer.parseInt(sc.nextLine());
                    incidenciaCtrl.eliminar(idEliminar);
                    break;
                case "5":
                    volver = true;
                    break;
                default:
                    System.out.println("Opción inválida, intente de nuevo.");
            }
        }
    }
}
