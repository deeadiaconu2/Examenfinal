/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import DAO.EmpleadoDAO;
import modelo.Empleado;

import java.util.List;
import java.util.regex.Pattern;
/**
 *
 * @author Usuario
 */
public class EmpleadoControlador {
    private EmpleadoDAO empleadoDAO = new EmpleadoDAO();

    public void agregarEmpleado(String nombre, String email) {
        if (nombre.isEmpty() || email.isEmpty()) {
            System.out.println("Nombre y correo no pueden estar vacíos.");
            return;
        }
        if (!Pattern.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$", email)) {
            System.out.println("Correo inválido.");
            return;
        }
        empleadoDAO.agregarEmpleado(new Empleado(0, nombre, email));
        System.out.println("Empleado agregado correctamente.");
    }

    public void mostrarTodos() {
        List<Empleado> lista = empleadoDAO.obtenerTodos();
        for (Empleado e : lista) {
            System.out.println(e.getId() + " - " + e.getNombre() + " - " + e.getEmail());
        }
    }

    public Empleado buscarPorId(int id) {
        return empleadoDAO.buscarPorId(id);
    }

    public void eliminar(int id) {
        empleadoDAO.eliminarEmpleado(id);
        System.out.println("Empleado eliminado.");
    }

    public void crearEmpleado(String nombre, String email) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
