/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import DAO.TecnicoDAO;
import modelo.Tecnico;
/**
 *
 * @author Usuario
 */
public class TecnicoControlador {
   private TecnicoDAO tecnicoDAO = new TecnicoDAO();

    public Tecnico login(String usuario, String password) {
        if (usuario == null || usuario.isEmpty() || password == null || password.isEmpty()) {
            System.out.println("Usuario o contraseña vacíos.");
            return null;
        }
        return tecnicoDAO.autenticar(usuario, password);
    }  

    public boolean autenticar(String usuario, String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
