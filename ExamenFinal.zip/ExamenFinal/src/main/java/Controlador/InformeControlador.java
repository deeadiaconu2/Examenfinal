/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import java.sql.*;
import util.ConexionBD;
/**
 *
 * @author Usuario
 */
public class InformeControlador {
    private Connection conexion;

    public InformeControlador() {
        conexion = ConexionBD.getConexion();
    }

    public void mostrarMenuInformes() {
        int opcion;
        do {
            System.out.println("\n--- Informes de Incidencias ---");
            System.out.println("1. Total de Incidencias por Empleado");
            System.out.println("2. Incidencias Abiertas por Prioridad");
            System.out.println("3. Tiempo promedio de resolución por Empleado");
            System.out.println("4. Volver al Menú Principal");

            opcion = util.Input.readInt("Seleccione una opción: ");
            switch (opcion) {
                case 1:
                    informeIncidenciasPorEmpleado();
                    break;
                case 2:
                    informePrioridadAbierta();
                    break;
                case 3:
                    informeTiempoPromedioResolucion();
                    break;
                case 4:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 4);
    }

    private void informeIncidenciasPorEmpleado() {
        String sql = """
            SELECT e.nombre,
                   SUM(i.estado = 'Abierta') AS abiertas,
                   SUM(i.estado = 'Cerrada') AS cerradas
            FROM empleados e
            LEFT JOIN incidencias i ON e.id = i.id_empleado
            GROUP BY e.nombre;
        """;

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n Total de Incidencias por Empleado:");
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                int abiertas = rs.getInt("abiertas");
                int cerradas = rs.getInt("cerradas");
                System.out.printf("Empleado: %s - Abiertas: %d - Cerradas: %d%n", nombre, abiertas, cerradas);
            }

        } catch (SQLException e) {
            System.out.println(" Error al obtener informe: " + e.getMessage());
        }
    }

    private void informePrioridadAbierta() {
        String sql = """
            SELECT prioridad, COUNT(*) AS total
            FROM incidencias
            WHERE estado = 'Abierta'
            GROUP BY prioridad;
        """;

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n Incidencias Abiertas por Prioridad:");
            while (rs.next()) {
                String prioridad = rs.getString("prioridad");
                int total = rs.getInt("total");
                System.out.printf("Prioridad %s: %d incidencias abiertas%n", prioridad, total);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener informe: " + e.getMessage());
        }
    }

    private void informeTiempoPromedioResolucion() {
        String sql = """
            SELECT e.nombre,
                   ROUND(AVG(DATEDIFF(i.fecha_resolucion, i.fecha_creacion)), 2) AS promedio_dias
            FROM empleados e
            JOIN incidencias i ON e.id = i.id_empleado
            WHERE i.estado = 'Cerrada' AND i.fecha_resolucion IS NOT NULL
            GROUP BY e.nombre;
        """;

        try (PreparedStatement stmt = conexion.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n Tiempo Promedio de Resolución por Empleado:");
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                double promedio = rs.getDouble("promedio_dias");
                System.out.printf("Empleado: %s - Promedio: %.2f días%n", nombre, promedio);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener informe: " + e.getMessage());
        }
    }

    public void mostrarInformeGeneral() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
