/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import DAO.IncidenciaDAO;
import modelo.Incidencia;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
/**
 *
 * @author Usuario
 */
public class IncidenciaControlador {
   private IncidenciaDAO incidenciaDAO = new IncidenciaDAO();

    public void registrarIncidencia(int idEmpleado, String descripcion, String prioridad) {
        if (descripcion.isEmpty() || prioridad.isEmpty()) {
            System.out.println("Descripción y prioridad obligatorias.");
            return;
        }

        if (!prioridad.equalsIgnoreCase("Alta") &&
            !prioridad.equalsIgnoreCase("Media") &&
            !prioridad.equalsIgnoreCase("Baja")) {
            System.out.println("Prioridad inválida.");
            return;
        }

        if (incidenciaDAO.existeIncidenciaCerradaConDescripcion(idEmpleado, descripcion)) {
            System.out.println("Ya existe una incidencia cerrada con esa descripción para este empleado.");
            return;
        }

        Incidencia inc = new Incidencia(0, idEmpleado, descripcion, prioridad, "Abierta", Date.valueOf(LocalDate.now()), null);
        incidenciaDAO.registrar(inc);
        System.out.println("Incidencia registrada correctamente.");
    }

    public List<Incidencia> listar() {
        List<Incidencia> lista = incidenciaDAO.listarTodas();
        for (Incidencia i : lista) {
            System.out.println("ID: " + i.getId() +
                    " | Empleado ID: " + i.getIdEmpleado() +
                    " | Prioridad: " + i.getPrioridad() +
                    " | Estado: " + i.getEstado() +
                    " | Descripción: " + i.getDescripcion());
        }
       return incidenciaDAO.listarTodas();
    }

    public void cambiarEstado(int idIncidencia, String nuevoEstado) {
        if (!nuevoEstado.equalsIgnoreCase("Abierta") &&
            !nuevoEstado.equalsIgnoreCase("En proceso") &&
            !nuevoEstado.equalsIgnoreCase("Cerrada")) {
            System.out.println("Estado inválido.");
            return;
        }

        Date fechaResolucion = nuevoEstado.equalsIgnoreCase("Cerrada")
                ? Date.valueOf(LocalDate.now())
                : null;

        incidenciaDAO.cambiarEstado(idIncidencia, nuevoEstado, fechaResolucion);
        System.out.println("Estado actualizado.");
    }

    public void eliminar(int id) {
        incidenciaDAO.eliminar(id);
        System.out.println("Incidencia eliminada.");
    } 

    public void registrar(Incidencia i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void mostrarListado() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
